# -*- coding: utf-8 -*-

import pandas as panda
import matplotlib.pylab as plt
import numpy as num
from sklearn.linear_model import LinearRegression
from sklearn import datasets
from sklearn.model_selection import train_test_split

data = panda.read_csv("turboaz.csv",delimiter=',')
data.head()

eliminator = lambda x: x.strip('km').replace(' ','')
feature1 = data['Yurush'].map(eliminator).map(int)

feature2 = data['Buraxilish ili']


data['Qiymet'] = data['Qiymet'].astype(str) 


eliminator1 = lambda x: float(x.rstrip('$'))*1.7 if '$' in x else float(x.rstrip('AZN'))
target = data['Qiymet'].map(eliminator1)

train_data = []
for data in range(len(feature1)):
    train_data.append([feature1[data],feature2[data]])
    
    
x_train, x_test, yTrain, yTest = train_test_split(train_data, target, test_size =0.2, random_state = 0)

linearmodel = LinearRegression()

linearmodel.fit(x_train, yTrain)

linearmodel.score(x_test, yTest)

train_data_test = [[415558,1996]]
ytest = [8800]



print(ytest)
print(linearmodel.predict(train_data_test))


