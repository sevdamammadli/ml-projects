# -*- coding: utf-8 -*-
"""
Created on Sun Feb  3 21:52:01 2019

@author: HP
"""
import pandas as pn
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
from mpl_toolkits.mplot3d import Axes3D

#reading data
df = pn.read_csv("turboaz.csv",delimiter=',')
df.head(5)

#extracting 3 columns from data
print(df[['Yurush','Buraxilish ili','Qiymet']])
df1=df[['Yurush','Buraxilish ili','Qiymet']]


#converting string to int and eliminating km 
eliminator = lambda x: x.strip('km').replace(' ','')
x = df['Yurush'].map(eliminator).map(int)

 

   
df['Qiymet'] = df['Qiymet'].astype(str) 

#eliminating $, AZN and converting $ to AZN

eliminator1 = lambda x: float(x.rstrip('$'))*1.7 if '$' in x else float(x.rstrip('AZN'))
y = df['Qiymet'].map(eliminator1)


#visualization between yurush and qiymet
plt.scatter(x, y, c='b')
plt.xlabel('Yurush')
plt.ylabel('Qiymet')
plt.title('Yurush ve Qiymet')
plt.show()


#visualization between qiymet and buraxilish ili
buraxilish = df['Buraxilish ili']
plt.scatter(y, buraxilish, c='b')
plt.xlabel('Qiymet')
plt.ylabel('Buraxilish ili')
plt.title('Buraxilish ve Qiymet')
plt.show()

 
    
#3d visualization between yurush, qiymet,buraxilish ili
fig = plt.figure()
ax = Axes3D(fig)
xs = x
ys = y
zs = df['Buraxilish ili']
ax.scatter(xs, ys, zs, color='b')

ax.set_xlabel('Yurush')
ax.set_ylabel('Qiymet')
ax.set_zlabel('Buraxilish ili')
plt.show()

#saving original
x1original = x
x2original = df['Buraxilish ili']
yoriginal = y

#normalization
y = (y-y.mean())/y.std()
f1 = (x-x.mean())/x.std()
f2 = df['Buraxilish ili']
f2 = (f2-f2.mean())/f2.std()

m = len(f1)
f0 = np.ones(m)
X = np.array([f0,f1,f2]).T
theta = np.array([0,0,0.5])
alpha = 0.001

def cost(F,Y,Te):
    m = len(Y)
    cfunction = np.sum((F.dot(Te)-Y)**2)/(2*m)
    return cfunction


initial_cost=cost(X,y,theta)


def gradient(X,Y,Te,alpha,iterations):
    costhistory = [0] * iterations
    m = len(Y)
    for iteration in range(iterations):
        H = X.dot(Te)
        diff = H - Y
        gradient = X.T.dot(diff)/m
        Te = Te - alpha * gradient
        mycost = cost(X,Y,Te)
        costhistory[iteration] = mycost
        
    return Te, costhistory

newTe, costhistory = gradient(X, y, theta, alpha, 100000)

print(newTe)  #1.682574483e-14 -9.33437483e-02 * f1 + 8.30867464e-01 * f2
print(costhistory[-1]) #0.10614288778721014

#
plt.plot(costhistory)
plt.xlabel("Cost")
plt.ylabel("Iterations")
plt.show()

#######################
prediction = newTe[0] + newTe[2]*f2
plt.scatter(f2,y)
plt.xlabel("Buraxilish ili")
plt.ylabel("Qiymet")
plt.plot(f2,prediction,c="b")
plt.show()


#######################
prediction = newTe[0] + newTe[1]*f1
plt.scatter(f1,y)
plt.xlabel("Yurush")
plt.ylabel("Qiymet")
plt.plot(f1,prediction,c="b")
plt.show()

#####################
predicted_qiymet = newTe[0] + newTe[1]*f1 + newTe[2]*f2
fig = plt.figure()
ax = fig.gca(projection="3d")
ax = Axes3D(fig)
ax.scatter(f1, f2, y, color='b')
ax.scatter(f1,f2,predicted_qiymet,c="r")
plt.show()

##Testing Car1
yurush = 240000
buraxilish = 2000
realqiymet = 11500

yurush = (yurush - x1original.mean())/x1original.std()
buraxilish = (buraxilish - x2original.mean())/x2original.std()
realqiymet = (realqiymet - yoriginal.mean())/yoriginal.std()

predict = newTe[0] + newTe[1]*yurush + newTe[2]*buraxilish

print(predict*yoriginal.std()+yoriginal.mean())
print(realqiymet*yoriginal.std()+yoriginal.mean())

#Testing Car2
yurush = 415558
buraxilish =  1996
realqiymet = 8800

yurush = (yurush - x1original.mean())/x1original.std()
buraxilish = (buraxilish - x2original.mean())/x2original.std()
realqiymet = (realqiymet - yoriginal.mean())/yoriginal.std()

predict = newTe[0] + newTe[1]*yurush + newTe[2]*buraxilish

print(predict*yoriginal.std()+yoriginal.mean())
print(realqiymet*yoriginal.std()+yoriginal.mean())





