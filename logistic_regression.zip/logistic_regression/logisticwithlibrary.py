# -*- coding: utf-8 -*-


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score 
import pandas as pn
import seaborn as sns; sns.set()

mydata = pn.read_csv("exams.csv")
print(mydata.head())

X, y = mydata.iloc[:,:2], mydata.iloc[:,2]


ax = sns.scatterplot(x="exam_1", y="exam_2", data=mydata,hue="admitted")

model = LogisticRegression()
model.fit(X, y)

predicted_classes = model.predict(X)
accuracy = accuracy_score(y,predicted_classes)


print(accuracy)


x_test = [[55.,70.],[40.,60.]]

predicted_y = model.predict(x_test)
print(predicted_y)