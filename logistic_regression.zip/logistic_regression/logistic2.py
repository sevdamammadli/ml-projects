# -*- coding: utf-8 -*-


import pandas as panda
import numpy as nm
import matplotlib.pyplot as pl
import seaborn as sn; sn.set()
from sklearn.metrics import accuracy_score
from scipy.optimize import minimize

mydata = panda.read_csv("exams.csv")
print(mydata.head())

X, y = mydata.iloc[:,:2], mydata.iloc[:,2]


ax = sn.scatterplot(x="exam_1", y="exam_2", data=mydata,hue="admitted")

# Sigmoid Function:
def sigmo(s):
    return 1 / (1 + nm.exp(-s))
costs = []

def cost(theta, X, y):
    
    
    m = len(y)
    
   
    e = 1e-15
    
    thetaX = sigmo(nm.dot(X, theta))
    
    J = - (nm.dot(y, nm.log(thetaX)) + nm.dot((1 - y), nm.log(1 - thetaX + e))) / m
    
    return J

def gradienT(theta, X, y):
    # Number of training examples
    m = len(y)
    
    thetaX = sigmo(nm.dot(X, theta))
    
    gradient =  nm.dot(X.T, (thetaX - y)) / m 
    
    return gradient

X = nm.hstack((nm.ones((X.shape[0],1)), X))

theta = nm.zeros(X.shape[1])
theta

J = cost(theta, X, y)
gradient = gradienT(theta, X, y)

print("Cost: %0.3f"%(J))
print("Gradient: {0}".format(gradient))



result = minimize(cost, theta, args=(X,y), method='BFGS', jac=gradienT, options={'maxiter' : 400, 'disp': True})
result

result['nit']

gradBFGS = result['x']



# X and Y in decision boundary
xplot = nm.array([nm.min(X[:, 2])-1, nm.max(X[:, 2])+1])
yplot = (-1 / gradBFGS[2]) * (gradBFGS[1] * xplot + gradBFGS[0])


# Plotting the data
ax = sn.scatterplot(x="exam_1", y="exam_2", data=mydata,hue="admitted")
pl.plot(xplot, yplot, c='b');

def predict(theta, X):
    thetaX = sigmo(nm.dot(X, theta))
    
    pre = []
    for tr in thetaX:
        if (tr > 0.5):
            pre.append(1)
        else:
            pre.append(0)
        
    return nm.array(pre)

p = predict(gradBFGS, X)

accuracy_score(p,y)

####predicting data
x = nm.array([[1,55.,70.],[1,40.,60.]])


my_predicted_scores= predict(gradBFGS,x)
print(my_predicted_scores)


