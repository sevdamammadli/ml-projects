# -*- coding: utf-8 -*-


import matplotlib.pyplot as plt
import seaborn as sns; sns.set()  # for plot styling
import numpy as np
from sklearn.datasets.samples_generator import make_blobs
from sklearn.cluster import KMeans
import pandas as pd


data = pd.read_csv("k-means.csv",names = ["a", "b"],sep='\t')

data =data.applymap(lambda x: str(x.replace(',','.')))

print(data.shape)
data.head()


data['b'] = pd.to_numeric(data['b'])
data['a'] = pd.to_numeric(data['a'])

fa = data['a'].values
fb = data['b'].values
X = np.array(list(zip(fa, fb)))
plt.scatter(fa, fb, c='black', s=7)

kmeans = KMeans(n_clusters=3)
kmeans.fit(X)
kmeansy = kmeans.predict(X)

plt.scatter(X[:, 0], X[:, 1], c=kmeansy, s=50, cmap='viridis')

center = kmeans.cluster_centers_
centroid = kmeans.cluster_centers_
print(centroid) 