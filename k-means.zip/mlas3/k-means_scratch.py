# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from copy import deepcopy


plt.rcParams['figure.figsize'] = (16, 9)
plt.style.use('ggplot')

data = pd.read_csv("k-means.csv",names = ["a", "b", "c"])

print(data.shape)
data.head()

a = []
b=[]
c=[]

for i in data['b']:
    i = ''.join(i.split())
    a.append(i)
    
data['b'] = a
data['b'] = pd.to_numeric(data['b'])    

maxb = np.max(data['b'])
minb = np.min(data['b'])
meanb = np.mean(data['b'])

maxc = np.max(data['c'])
minc = np.min(data['c'])

minb = pd.to_numeric(minb)

for i in data['b']:
    i = (i - meanb) / (maxb - minb)*20
    b.append(i)
    
    
data['b'] = b 

for i in data['c']:
    i = (i - data['c'].mean()) / (maxc - minc)*20
    c.append(i)

data['c'] = c

f1 = data['a'].values
f2 = data['b'].values
f3 = data['c'].values
X = np.array(list(zip(f2, f3)))
plt.scatter(f2, f3, c='black', s=7)

def dist(a, b, ax=1):
    return np.linalg.norm(a - b, axis=ax)

k = 3
# X coordinates of random centroids
C_x = np.random.uniform(0,1,size=k)
# Y coordinates of random centroids
C_y = np.random.uniform(0,1,size=k)
C = np.array(list(zip(C_x, C_y)), dtype=np.float32)
print(C)

plt.scatter(f2, f3, c='#050505', s=7)
plt.scatter(C_x, C_y, marker='*', s=200, c='g')



def findClosestCentroids(X, centroids):
    """
    Returns the closest centroids in idx for a dataset X where each row is a single example.
    """
    K = centroids.shape[0]
    idx = np.zeros((X.shape[0],1))
    temp = np.zeros((centroids.shape[0],1))
    
    for i in range(X.shape[0]):
        for j in range(K):
            dist = X[i,:] - centroids[j,:]
            length = np.sum(dist**2)
            temp[j] = length
        idx[i] = np.argmin(temp)+1
    return idx
# Select an initial set of centroids
K = 3
initial_centroids = np.array([[0.2,0.9],[0.2,0.4],[0.04,0.7]])
idx = findClosestCentroids(X, initial_centroids)
print("Closest centroids for the first 3 examples:\n",idx[0:3])

def computeCentroids(X, idx, K):
    """
    returns the new centroids by computing the means of the data points assigned to each centroid.
    """
    m, n = X.shape[0],X.shape[1]
    centroids = np.zeros((K,n))
    count = np.zeros((K,1))
    
    for i in range(m):
        index = int((idx[i]-1)[0])
        centroids[index,:]+=X[i,:]
        count[index]+=1
    
    return centroids/count
centroids = computeCentroids(X, idx, K)
print("Centroids computed after initial finding of closest centroids:\n", centroids)

def plotKmeans(X, centroids, idx, K, num_iters):
    """
    plots the data points with colors assigned to each centroid
    """
    m,n = X.shape[0],X.shape[1]
    
    fig, ax = plt.subplots(nrows=num_iters,ncols=1,figsize=(6,36))
    
    for i in range(num_iters):    
        # Visualisation of data
        color = "rgb"
        for k in range(1,K+1):
            grp = (idx==k).reshape(m,1)
            ax[i].scatter(X[grp[:,0],0],X[grp[:,0],1],c=color[k-1],s=15)
# visualize the new centroids
        ax[i].scatter(centroids[:,0],centroids[:,1],s=120,marker="x",c="black",linewidth=3)
        title = "Iteration Number " + str(i)
        ax[i].set_title(title)
        
        # Compute the centroids mean
        centroids = computeCentroids(X, idx, K)
        
        # assign each training example to the nearest centroid
        idx = findClosestCentroids(X, centroids)
    
    plt.tight_layout()
m,n = X.shape[0],X.shape[1]
plotKmeans(X, initial_centroids,idx, K,10)