# -*- coding: utf-8 -*-

from copy import deepcopy
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
plt.rcParams['figure.figsize'] = (16, 9)
plt.style.use('ggplot')
dt = pd.read_csv('k-means.csv', names = ["a", "b"], sep='\t')
dt =dt.applymap(lambda x: str(x.replace(',','.')))

print(dt.shape)
dt.head()


dt['b'] = pd.to_numeric(dt['b'])
dt['a'] = pd.to_numeric(dt['a'])

fa = dt['a'].values
fb = dt['b'].values
X = np.array(list(zip(fa, fb)))
plt.scatter(fa, fb, c='black', s=7)

def distance(a, b, ax=1):
    return np.linalg.norm(a - b, axis=ax)


k = 3
Cx = np.random.randint(0, np.max(X), size=k)
Cy = np.random.randint(0, np.max(X), size=k)
Cf = np.array(list(zip(Cx, Cy)), dtype=np.float32)


plt.scatter(fa, fb, c='#f4425c', s=7)
plt.scatter(Cx, Cy, marker='*', s=200, c='g')


Cold = np.zeros(Cf.shape)
clusters = np.zeros(len(X))
err = distance(Cf, Cold, None)
while err != 0:
    for i in range(len(X)):
        distances = distance(X[i], Cf)
        cluster = np.argmin(distances)
        clusters[i] = cluster
    Cold = deepcopy(Cf)
    for i in range(k):
        points = [X[j] for j in range(len(X)) if clusters[j] == i]
        Cf[i] = np.mean(points, axis=0)
    error = distance(Cf, Cold, None)
    
col = ['r', 'g', 'b', 'y', 'c', 'm']
fig, ax = plt.subplots()
for i in range(k):
        points = np.array([X[j] for j in range(len(X)) if clusters[j] == i])
        ax.scatter(points[:, 0], points[:, 1], s=7, c=col[i])
ax.scatter(Cf[:, 0], Cf[:, 1], marker='*', s=200, c='#050505')